#include"stdio.h"
main()
{
	char cZiFu;
	cZiFu=getchar();
	putchar(cZiFu); 
}
