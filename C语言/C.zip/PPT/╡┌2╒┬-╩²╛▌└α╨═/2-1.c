#include"stdio.h"
main()
{
	char o='O',k='K';
	putchar(o);
	putchar(k);
	putchar('\n');
	putchar('*');
}
