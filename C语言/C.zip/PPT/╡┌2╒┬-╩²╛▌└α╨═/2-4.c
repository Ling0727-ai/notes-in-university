#include"stdio.h"
main()
{
	char cZiFu='a'; 
	printf("%c, %d\n", 'a', 'a');
	printf("%c, %d\n", 97, 97); 
	printf("%c, %d\n",98, 'a'+1); 
	printf("%c, %d\n", cZiFu-'a'+'A', cZiFu-'a'+'A'); 
}
