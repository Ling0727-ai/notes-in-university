#define  PI  3.14159
main( )                   /* ������*/
{	
	int   r, h;  	
	float  v;
	printf("\nInput   r  h = ");
	scanf("%d%d",  &r,  &h);
	printf("PI=%-8.3da\n", PI);
	printf("r=%d         h=%d \t v=%f\n\n",  r,  h, PI*r*r*h);
}
