#include"stdio.h"
main()
{
	double fShuJu=3.1415926;
	printf("%f, %e\n", fShuJu, fShuJu);
	printf("%5.3f, %5.2f, %.2f\n", fShuJu, fShuJu, fShuJu);
}
