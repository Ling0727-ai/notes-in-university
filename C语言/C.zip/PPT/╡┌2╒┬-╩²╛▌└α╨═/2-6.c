#include<stdio.h>
#include<math.h>
 main( )
{
	float a,b,c,disc,x1,x2,p,q;
	printf("enter a,b,c:");
	scanf("%f,%f,%f",&a,&b,&c);
	disc=b*b-4*a*c;
	p= -b/(2*a);
    q=sqrt(disc)/(2*a);
	x1=p+q;
    x2=p-q;
	printf("a=%7.2f b=%7.2f c=%7.2f\n",a,b,c);	
	printf("x1=%7.2f\nx2=%7.2f\n",x1,x2);
}
