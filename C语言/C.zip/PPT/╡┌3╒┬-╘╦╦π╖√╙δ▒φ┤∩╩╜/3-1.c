void main()
{
	int nShu1=5, nShu2=10;
    float fJieGuo1, fJieGuo2;
    fJieGuo1 = nShu1/nShu2;
    fJieGuo2 =(float)nShu1/nShu2;
    printf("JieGuo1=%.2f, JieGuo2=%.2f\n", fJieGuo1, fJieGuo2);
} 
