#include <stdio.h>
void main()
{
	int nShu1, nShu2, nShu3=322;
	double fShu1 = 3.1415926535;
	float fShu2;
	char cShu1='k', cShu2;
	nShu1 = fShu1;
	fShu2 = fShu1;
	cShu2 = nShu3;
	nShu2 = cShu1;
	printf("nShu1=%d, fShu1=%.8lf, fShu2=%.8f, nShu2=%d, cShu2=%c",nShu1 ,fShu1, fShu2, nShu2, cShu2);
} 
