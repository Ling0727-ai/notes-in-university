#include <stdio.h>
void main()
{
	int nShu1=5000, nShu2=31893, nJieGuo1, nJieGuo2;
	nJieGuo1 = (nShu1 + nShu2) / 5;
	nJieGuo2 = (0L + nShu1 + nShu2) / 5;
	printf("nJieGuo1=%d, nJieGuo2=%d\n", nJieGuo1, nJieGuo2);
} 
