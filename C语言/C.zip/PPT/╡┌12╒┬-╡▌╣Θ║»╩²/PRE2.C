#include <stdio.h>

#define S(r) r = r*r;

void test(int r);
main()
{
	int num = 123;
	printf("number = %d\n", num);
	test(num);
	printf("test number = %d\n", num);
	S(num) num=num*num;
	printf("S(r) number = %d\n", num);
}

void test(int r)
{
	r = r*r;
}