#include <stdio.h>

#define LONG long int
#define UINT unsigned LONG

main()
{
	LONG m_lNumber = 1234;
	UINT m_uNumber = 123;
	printf("LONG number = %ld\n", m_lNumber);
	printf("UINT number = %ld\n", m_uNumber);
}