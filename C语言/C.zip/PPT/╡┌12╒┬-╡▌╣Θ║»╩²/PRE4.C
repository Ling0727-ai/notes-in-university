#include <stdio.h>
#define PI 3.1415926
#define S(r) PI*r*r
#define C(r) PI*2*r

main()
{
	int r = 2;
	float area, circle;
	area = S(r);
	circle = C(r);
	printf("radium = %d, area = %f, circle = %f\n", r, area, circle);
}
