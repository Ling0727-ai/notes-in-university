#include <stdio.h>

#define S(r) r*r;

main()
{
	int num = 3;
	int num1;
	printf("number = %d\n", num);
	num1 = S(num);
	printf("S(r) number = %d, number1 = %d\n", num, num1);
	num1 = S(num+2)
	printf("S(r) number = %d, number1 = %d\n", num, num1);
}
