#include <stdio.h>

//#define DEBUG

main()
{
	int a[10];
	int i;
	printf("Please input 10 numbers:\n");
	for(i=0; i<10; i++)
	{
		printf("a[%d] =  ", i);
		scanf("%d", &a[i]);
	}
	printf("--------------------------------\noriginal:");
	for(i=0; i<10; i++)
	{
		printf(" %d", a[i]);
	}
	printf("\n--------------------------------\n");
	for(i=1; i<10; i++)
	{
		int j;
		for(j=0; j<10-i; j++)
		{
			if(a[j] > a[j+1])
			{
				int temp = a[j];
				a[j] = a[j+1];
				a[j+1] = temp;
			}
		}
#ifdef DEBUG
		printf("No. %d: ", i);
		for(j=0; j<10; j++)
		{
			printf("%d ", a[j]);
		}
		printf("\n");
#endif
	}
	printf("--------------------------------\nsorted:");
	for(i=0; i<10; i++)
	{
		printf(" %d", a[i]);
	}
}