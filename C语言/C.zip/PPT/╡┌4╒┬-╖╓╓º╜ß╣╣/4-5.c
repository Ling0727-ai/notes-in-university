#include <stdio.h>
main(  )
{ 
      int num;
      printf("\nPlease input a number:");
      scanf("%d",&num);
     if ( num > 100 )
          printf("great that 100. \n");
     else 
          printf("less that or equal to 100 .\n");
}
