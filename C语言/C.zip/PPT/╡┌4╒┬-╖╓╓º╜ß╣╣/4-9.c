#include <stdio.h>
main(  )
{  
	char a;
    printf("Please input the salary level \n ");
    printf("Between 1 to 5, which is char type. \n");
    scanf("%c",&a);
    switch(a)
	{ 
	case '1': 
		printf("taxis=40% \n");
		break;     
	case '2': 
		printf("taxis=30% \n");
		break;
	case '3': 
		printf("taxis=20% \n");
		break;
	case '4': 
		printf("taxis=8% \n");
		break;
	case '5': 
		printf("taxis=0% \n");
		break;
	default:  
		printf("Error");
	} 
}    
