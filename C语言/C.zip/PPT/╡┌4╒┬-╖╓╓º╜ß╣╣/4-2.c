#include <stdio.h>
main()
{
	int nFenZi, nFenMu;
	printf("Qing ShuRu BeiChuShu he ChuShu: ");
	scanf("%d%d", &nFenZi, &nFenMu);
	if(nFenMu)
		printf("%d", nFenZi / nFenMu); 
} 
