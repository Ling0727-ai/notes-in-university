#include <stdio.h>

main()
{
	int c,grade;
	printf("input grade(0-00):\b"); 
	scanf("%d",&grade);
	if(grade>100) 	
		printf("wrong grade\n");
	else if(grade<60) 	
		printf("failed\n");
	else
	{     
		c=grade/10;
		
		switch(c)
		{
		case 6:
			printf("grade D\n");
			break;
		case 7:
			printf("grade C\n");
			break;
		case 8:
			printf("grade B\n");
			break;
		case 9:
			printf("grade A\n");
			break;
		case 10:
			printf("grade A\n");
			break;
		}
    }
	
}