#include <stdio.h>
int main(void)
{
	float fShuJu1,fShuJu2,fLinShi;
	printf("input fShuJu1,fShuJu2:");
	scanf("%f,%f",&fShuJu1,&fShuJu2);
	if( fShuJu1 < fShuJu2 )	
	{
		fLinShi=fShuJu1;
		fShuJu1=fShuJu2; 
		fShuJu2=fLinShi;
	}
	printf("%f,%f\n",fShuJu1,fShuJu2);
} 
