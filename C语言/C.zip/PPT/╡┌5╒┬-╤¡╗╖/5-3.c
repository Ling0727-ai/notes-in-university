#include <stdio.h>
main()
{ 	
	int  i =0;  
	float  sum=0;

	while  (i<100)
	{	
		++i ; 
		sum += 1.0/ i ;		
	}
	printf("n=%d   sum=%-8.3f\n",  i, sum);
}
