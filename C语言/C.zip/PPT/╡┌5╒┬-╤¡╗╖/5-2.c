#include <stdio.h>
void main()
{
	int m,n,result;
	printf("input two integers:");
	scanf("%d%d",&m,&n);
	result=m<n?n:m;
	while(!(result%m==0&&result%n==0)) 
		result++;
	printf("the result is %d\n",result);
} 
