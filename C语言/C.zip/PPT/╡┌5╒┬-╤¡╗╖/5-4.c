#include <stdio.h>
main( )
{  
	int n;
	printf("Enter a integer with 1 to 7.\n");
	do
	{ 
		scanf("%d",&n);
		switch(n)
		{ 
			case 1: 
				printf("MON\n"); 
				break;
	       case 2: 
			   printf("TUE\n"); 
			   break;
		   case 3: 
			   printf("WED\n"); 
			   break;
		   case 4: 
			   printf("THU\n"); 
			   break;
		   case 5: 
			   printf("FRI\n"); 
			   break;
		   case 6: 
			   printf("SAT\n"); 
			   break;
		   case 7: 
			   printf("SUN\n"); 
			   break;
   	       default: 
			   printf("Error\n"); 
			   break;
		}
	} while(n!=0);
}
