#include "stdio.h"
main( )
{ 
	int i,j,a,b,c,d;
    for(i=32;i<=99;i++)
	{ 
		j=i*i;  
		a=j/1000; 
		b=j/100-a*10;
		c=j/10-a*100-b*10;
		d=j-a*1000-b*100-c*10;
		if (a+c==10&&b*d==12)
			printf("%d    ",j);
	}
}
