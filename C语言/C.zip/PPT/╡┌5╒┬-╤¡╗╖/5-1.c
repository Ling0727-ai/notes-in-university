#include <stdio.h>
main(  )
{
	int n, sum;
    n=1;
    sum=0;
    while(n<=100)
	{  
		sum=sum+n;
		n++;
	}
    printf("sum=%d \n",sum);
}     
