#include <stdio.h>
main()
{
	int     i;
	float    a=2, b=1, s=0, w;
	for(  i=1; i<= 20 ; i++ )
	{  
		s = s+a/b;
		w= a;  
		a= a+b;  
		b= w;
	}
	printf("sum=%f\n",s);
}
