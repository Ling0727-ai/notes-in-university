#include <stdio.h>
main( )
{ 
	int x=0;
	int e=1;
	do{ 
		x=x+1;
		if((x+3)%5==0&&(x-3)%6==0) 
			e=0;
	} while(e);
	printf("\nx=%d",x);
}
