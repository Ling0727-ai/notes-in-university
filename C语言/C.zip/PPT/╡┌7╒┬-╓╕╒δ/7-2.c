#include <stdio.h>
main()
{  int x=5,y=10;
    int *px,*py;
    px=&x;
    py=&y;
    *px=*px+*py;
    *py=*px**py;
    printf(��%d  %d��,*px,*py);
 }