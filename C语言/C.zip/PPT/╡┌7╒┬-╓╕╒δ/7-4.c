#include <stdio.h>
swap(int *x,int *y)
{  
	int t;
	t=*x;
	*x=*y;
	*y=t;
}
main()
{
	int  a=1,b=2,*aa,*bb;
	aa=&a;
	bb=&b;
	swap(aa,bb);
	printf("%d,%d",a,b);
	
}