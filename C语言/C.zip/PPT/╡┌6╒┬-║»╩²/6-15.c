#include <stdio.h>
int f(int a)
{
    int b=0;
    static int c=3;
    a++; b++; c++;
    return a+b+c;
}
void main()
{
    int x=2, i;
    for(i=0;i<3;i++)
        printf("%d\n",f(x));
}