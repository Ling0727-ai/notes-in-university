#include <stdio.h>
main(  )
{ 
	float factorial(int);
	int k;
	float sum;
	for(k=1,sum=0;k<=10;k++)
		sum=sum+factorial(k);
	printf("1!+2!+...+n!=%e\n",sum);  
}
float  factorial(int n)
{ 
	float product;
	for(product=1; n>0; n--)
		product *= n;
	return(product);
}
