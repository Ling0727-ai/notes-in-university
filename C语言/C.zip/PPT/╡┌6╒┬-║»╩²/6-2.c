#include <stdio.h>
main( )
{ 
	int x, y, z, m;
	float max(float a, float b, float c);
	scanf("%f  %f %f", &x, &y, &z);
	m=max(x,y,z);
	printf("\n%f:",m);
}
float max(float a, float b, float c)
{ 
	float result;
    result=a;
    if(result<b) 
		result=b;
    if(result<c) 
		result=c;
    return(result);
}
