#include <stdio.h>
float add(float x, float y)
{   
	static float z; 
	z=z+x+y;
	return(z);
}
main( )
{ 
	float s,x=2,y=3;
	s=add(x,y);
	printf("s=%f\n", s);
	s=add(x,y);
	printf("s=%f\n", s);
}
