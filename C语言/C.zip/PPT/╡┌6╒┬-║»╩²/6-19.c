#include <stdio.h>
extern int a,b;
int max()
{  
	int z;
	z=a>b?a:b;
	return(z);
}
main()
{ 
	printf("max=%d",max());
}
int a=13,b=18;
