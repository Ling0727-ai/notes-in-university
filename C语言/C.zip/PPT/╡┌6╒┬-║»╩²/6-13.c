#include <stdio.h>
int i=10;
main( )
{ 
	int j=0;
   j=func( );
   printf("\nj=%d",j);
   j=func( );
   printf("\nj=%d",j);
}
int func( )
{ 
	int k=0;
    k=k+i;
    i=i+10;
    return(k);
}
