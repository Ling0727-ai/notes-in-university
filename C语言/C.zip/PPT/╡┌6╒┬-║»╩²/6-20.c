#include <stdio.h>
main( )
{ 
	int a=3,b=2,c=1;
	c-=++b;
	b*=a+c;
    { 
		int b=5;
		int c=12;
		c/=b*2;
		a-=c;
		printf("\na=%d  b=%d  c=%d\n",a,b,c);
		a+=--c;
	}
	printf("a=%d  b=%d  c=%d\n",a,b,c);
}
