#include <stdio.h>
main( )
{ 
	int n;
    printf("Enter a integer:");
    scanf("%d",&n);
    printf("result:%d",func(n));
}
int func(int num)
{  
	int s=0;
    num=abs(num);
    do
	{  
		s=s+num%10;
		num=num/10;
	}while(num);
    return(s);
}
