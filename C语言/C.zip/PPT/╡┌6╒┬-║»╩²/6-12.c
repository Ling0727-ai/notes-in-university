#include <stdio.h>
int x=0,y=0,z=0;
other( )
{ 
	int x=100,y=200;
    printf("other\n");
    printf("x=%d y=%d z=%d\n",x,y,z);
 }
main( )
{ 
	int x=1,y=2,z=3;
    printf("\nmain\n");
    printf("x=%d y=%d z=%d\n",x,y,z);
    other( );
}
