#include <stdio.h>
float  factorial(int n)
{ 
	float product;
	for( product=1;n>0;n--)
		product *= n;
	return(product);
}
main(  )
{ 
	int n;
	printf("Enter integer n:");
	scanf("%d",&n);
	printf("n!=%e\n",factorial(n));
}