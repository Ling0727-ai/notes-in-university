#include <stdio.h>
void main()
{ 
	int k=1;
	static int x=10;
	void other();
	printf("\n----main----\n");
	printf("k=%d  x=%d\n",k,x);
	other();
	printf("----main----\n");
	printf("k=%d x=%d\n",k,x);
	other();
}
void other()
{  
	int k=100;
	static int x=200;
	x+=100;
	printf("----other----\n");
	printf("k=%d x=%d\n",k,x);
}
