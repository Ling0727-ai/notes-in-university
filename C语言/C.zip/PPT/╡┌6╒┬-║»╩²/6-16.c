#include <stdio.h>
main( )
{  
	int s,i;
    int sum( );
    for(i=1;i<=10;i++)
          s=sum(i);
    printf("s=%d\n",s);
 }
int sum(int k)
{
    static int x=0;
    return(x+=k);
}
