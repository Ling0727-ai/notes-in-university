#include <stdio.h>
PingJunZhi(float fShuZhi1, float fShuZhi2)
{
	float fPingJunZhi;
	fPingJunZhi = (fShuZhi1+ fShuZhi2)/2.0;
	printf("PingJunZhi HanShu: fShuZhi1=%f, fShuZhi2=%f, fPingJunZhi =%f\n", fShuZhi1, fShuZhi2, fPingJunZhi);
	return fPingJunZhi;
}
void main()
{
	float fShu1=1.8, fShu2=2.6, fPingJun=3;
	fPingJun = PingJunZhi (fShu1, fShu2);
	printf("main: fShu1=%f, fShu2=%f, fPingJun =%f\n", fShu1, fShu2, fPingJun);
}
