#include <stdio.h>
float PingJunZhi(int nShuZhi1, int nShuZhi2)
{
	float fPingJunZhi;
	fPingJunZhi = (nShuZhi1+ nShuZhi2)/2.0;
	printf("PingJunZhi HanShu: nShuZhi1=%d, nShuZhi2=%d, fPingJunZhi =%f\n", nShuZhi1, nShuZhi2, fPingJunZhi);
	return fPingJunZhi;
}
void main()
{
	float fShu1=1.8, fShu2=2.6, fPingJun=3;
	fPingJun = PingJunZhi (fShu1, fShu2);
	printf("main: fShu1=%f, fShu2=%f, fPingJun =%f\n", fShu1, fShu2, fPingJun);
}
