#include <stdio.h>
main( )
{  
	int a[]={1,2,3,4};
    int i,j,s;
    for(i=3,j=1,s=0; i>=0; i--)
	{ 
		s=s+a[i]*j;
		j=j*10;
	}
    printf("s=%d\n",s);
}
