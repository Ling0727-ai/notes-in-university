#include <stdio.h>
main()
{
	int nYear, nMonth, nLeap;
	int nDay[2][12] = {
		{31,28,31,30,31,30,31,31,30,31,30,31},
		{31,29,31,30,31,30,31,31,30,31,30,31}
	};
	printf("Please input year:");
	scanf("%d", &nYear);
	printf("Please input month:");
	scanf("%d", &nMonth);
	if(nMonth>0 && nMonth<13)
	{
		if((nYear%4==0&&nYear%100!=0)||(nYear%400==0))   
			nLeap = 1;
		else      
			nLeap = 0;
		printf("Year:%d, Month:%d Toatal Day:%d\n", nYear, nMonth, nDay[nLeap][nMonth-1]);
	}
	else     
		printf("Error month.\n");
}
