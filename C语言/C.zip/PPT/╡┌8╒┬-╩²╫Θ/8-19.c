#include <stdio.h>
main()
{
	int i;
	char str1[20];
	char str2[20];
	printf("\nplease input a string:");
	gets(str1);
	printf("please inupt the string again:");
	scanf("%s", str2);
	printf("str1:%s\n", str1);
	printf("str2:%s\n", str2);
}
