#include <stdio.h>
#include <stdio.h>
void main()
 {
       int iarray[10]={0,2,4,6,8,10,12,14,16,18};
       int i, sum=0;
       int *iptr=iarray;    /*ָ��ָ������*/
       for(i=0;i<10;i++)
	   {
             sum+=*iptr;
             iptr++;     
       }
       printf("sum is %d\n",sum);
 }