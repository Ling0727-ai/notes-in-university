#include <stdio.h>
main( )
{  int n[3];
    int i,j,k;
    for(i=0; i<3; i++)
           n[i]=0;
    k=2;
    for( i=0; i<k; i++ )
         for( j=0; j<k; j++ )
                n[ j ]=n[i]+1;
    printf("n[0]=%d\n",n[0]);
    printf("n[1]=%d\n",n[1]);
    printf("n[2]=%d\n",n[2]);
}
