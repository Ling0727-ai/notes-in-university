#include  <stdio.h>  
void  main(void)  
{
	float fScore[5],fAver=0;
	int i;
	for(i=0;i<5;i++) 
	{
		printf("input  the score of  %d ��",i+1);
		scanf("%f",&fScore[i]); 
		fAver+=fScore[i];
	}
	fAver/=5;
	printf("the average=%f \n",fAver);
	for( i = 0; i < 5; i++) 
	{
        if(fScore[i]<fAver)
			printf("num=%d,score=%f \n" ,i+1,fScore[i]);
	}
} 
