#include <stdio.h>
#define N 7
void main()
{
	int i, a[N]={4, 7, 6, 3, 1, 5, 2};
	for (i=0; i<N/2; i++)
	{
		int nTemp = a[i];
		a[i] = a[N-i-1];
		a[N-i-1] = nTemp;
	}
	for (i=0; i<N; i++)
	{
		printf("a[%d] = %d\n", i, a[i]);
	}
}
