#include <stdio.h>
void main()
{
	int i,a[10], *pa = a;
	for ( i=0; i<=9;i++)
		pa[i]=i;
	for( i=9;i>=0; i-- )
		printf("%d",*(pa+i));
	printf("\n");
} 
