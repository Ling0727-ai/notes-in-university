main()
{
	int i;
	char str1[] = {'1','2','3','4','5','6'};
	char str2[] = "123456";
	printf("\nstr1:");
	for(i=0; i<7; i++)
		printf("%d, ", str1[i]);
	printf("\nstr2:");
	for(i=0; i<7; i++)
		printf("%d, ", str2[i]);
	printf("\n");
	printf("str1:%s\n", str1);
	printf("str2:%s\n", str2);
}
