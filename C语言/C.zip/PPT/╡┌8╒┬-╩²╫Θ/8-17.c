#include <stdio.h>
#include <stdio.h>
void OutPut(int n, int a[10])
{
	int i;
	for(i=n; i>=0; i--)
		printf("%d ", *(a+i));
	printf("\n");
}
void main()
{
	int i, a[10];
	for (i=0; i<=9; i++)
		a[i]=i;
	OutPut(9, a);
} 
