#include <stdio.h>
#define SIZE 10
main()
{  
	int x[SIZE],i,max,min;
    printf("Enter 10 integers:\n");
    for(i=0;i<SIZE;i++)
    {   
		printf("%d:",i+1);
		scanf("%d",&x[i]);
    }
    max=min=x[0];
    for(i=1;i<SIZE;i++)
    {  
		if(x[i]>max)  
			max=x[i];
		if(x[i]<min) 
			min=x[i];
    }
    printf("Maximum value is %d\n",max);
    printf("Minimum value is %d\n",min);
}
