#include <stdio.h>
main()
{
	int a[10], i, j;
	printf("Please input 10 numbers:\n");
	for(i=0; i<10; i++)
	{
		printf("a[%d] =  ", i);
		scanf("%d", &a[i]);
	}
	printf("--------------------------------\noriginal:");
	for(i=0; i<10; i++)	
		printf(" %5d", a[i]);
	printf("\n--------------------------------\n");
	for(i=1; i<10; i++)
	{
		for(j=0; j<10-i; j++)
		{
			if(a[j] > a[j+1])
			{
				int temp = a[j];
				a[j] = a[j+1];
				a[j+1] = temp;
			}
		}
		printf("No. %d: ", i);
		for(j=0; j<10; j++)  
			printf("%5d ", a[j]);
		printf("\n");
	}
}
