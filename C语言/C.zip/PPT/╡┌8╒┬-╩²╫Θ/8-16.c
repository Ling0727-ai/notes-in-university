#include <stdio.h>
void OutPut(int n, int *pa)
{
	int i;
	for(i=n;i>=0; i-- )
		printf("%d", *(pa+i));
	printf("\n");
}
void main()
{
	int i, a[10];
	for (i=0; i<=9;i++)
		a[i]=i;
	OutPut(9, a);
} 
