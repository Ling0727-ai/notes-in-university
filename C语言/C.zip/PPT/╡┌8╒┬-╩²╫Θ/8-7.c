#include <stdio.h>
void main()
{
	int i, a[7]={1, 3, 5, 7, 9, 11};
	for (i=6; i>2; i--)
	{
		a[i] = a[i-1];
	}
	a[2] = 4;
	for (i=0; i<7; i++)
	{
		printf("a[%d] = %d\n", i, a[i]);
	}
}
