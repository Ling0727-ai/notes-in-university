#include <stdio.h>
int large(int x,int y) 
{
	int flag;
	if(x>y)  
		flag=1;
	else if(x<y)   
		flag=-1;
	else   
		flag=0;
	return (flag) ;
}
main( )
{    
	int a[10],b[10],i,n=0,m=0,k=0;
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
		scanf("%d",&b[i]);
	}
	for(i=0;i<10;i++)
	{  
		switch( large(a[i],b[i]) )
		{  
		case 1:
			n++;
			break;
        case -1:
			m++;
			break;
        case 0:
			l++;  
			break;
		}  
	}
	if(n>k)
		printf("a>b");
	else if(n<k) 
		printf("a<b");
	else 
		printf("a=b");
}
