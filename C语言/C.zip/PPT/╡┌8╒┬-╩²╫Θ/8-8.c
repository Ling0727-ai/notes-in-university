#include <stdio.h>
void main()
{
	int i, a[ ]={1, 3, 5, 7, 9, 11, 13};
	for (i=2; i<6; i++)
	{
		a[i] = a[i+1];
	}
	for (i=0; i<7; i++)
	{
		printf("a[%d] = %d\n", i, a[i]);
	}
}
