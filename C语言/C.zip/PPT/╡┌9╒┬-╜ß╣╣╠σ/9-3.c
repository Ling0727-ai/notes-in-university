#include <stdio.h>

struct date
{
	int year;
	int month;
	int day;
};

struct student
{
	char name[11];
	char sex;
	char StudentID[10];
	struct date birthday;
	float score;
};

main()
{
	struct student TheStudent[10];
	int i;
	char cTemp, *pt;
	for(i=0; i<3; i++)
	{
		printf("please input the %dth student's infomation\n", i+1);
		printf("name:");
		pt = TheStudent[i].name;
		do{
			cTemp = getchar();
			*pt++ = cTemp;
		}while(cTemp != '\n');
		*(pt-1) = '\0';/*different: *(pt--) = '\0';*/
		printf("sex:");
		TheStudent[i].sex = getchar();
		printf("student ID:");
		scanf("%s", TheStudent[i].StudentID);
		printf("birthday:");
		scanf("%d,%d,%d", &TheStudent[i].birthday.year, &TheStudent[i].birthday.month, &TheStudent[i].birthday.day);
		cTemp = getchar();
	}
	printf("result:\n");
	for(i=0; i<3; i++)
	{
		printf("pthe %dth student's infomation\n", i+1);
		printf("name: %s\n", TheStudent[i].name);
		switch(TheStudent[i].sex)
		{
		case 'm':
			printf("sex: male\n");
			break;
		case 'f':
			printf("sex: female\n");
			break;
		}
		printf("student ID:%s\n", TheStudent[i].StudentID);
		printf("birthday:%d,%d,%d\n", TheStudent[i].birthday.year, TheStudent[i].birthday.month, TheStudent[i].birthday.day);
	}
}