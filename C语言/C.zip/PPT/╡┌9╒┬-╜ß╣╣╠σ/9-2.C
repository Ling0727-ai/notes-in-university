#include <stdio.h>

struct date
{
	int year;
	int month;
	int day;
};

struct student
{
	char name[11];
	char sex;
	char StudentID[10];
	struct date birthday;
	float score;
};

main()
{
	struct student TheStudent;
	printf("please input student's infomation\n");
	printf("name:");
	gets(TheStudent.name);/*different :scanf("%s", TheStudent.name);*/
	printf("sex:");
	TheStudent.sex = getchar();
	printf("student ID:");
	scanf("%s", TheStudent.StudentID);
	printf("birthday:");
	scanf("%d,%d,%d", &TheStudent.birthday.year, &TheStudent.birthday.month, &TheStudent.birthday.day);
	printf("result:\n");
	printf("name: %s\n", TheStudent.name);
	switch(TheStudent.sex)
	{
	case 'm':
		printf("sex: male\n");
		break;
	case 'f':
		printf("sex: female\n");
		break;
	}
	printf("student ID:%s\n", TheStudent.StudentID);
	printf("birthday:%d,%d,%d", TheStudent.birthday.year, TheStudent.birthday.month, TheStudent.birthday.day);
}