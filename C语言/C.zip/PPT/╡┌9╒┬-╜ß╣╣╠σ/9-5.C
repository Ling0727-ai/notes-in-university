#include <stdio.h>

struct date
{
	int year;
	int month;
	int day;
};

struct student
{
	char name[11];
	char sex;
	char StudentID[10];
	struct date *birthday;
	float score;
};

main()
{
	struct student *TheStudent;
	//struct date TheDate;
	TheStudent = (struct student*)malloc(sizeof(struct student));
	TheStudent->birthday = (struct date*)malloc(sizeof(struct date));
	strcpy(TheStudent->name, "li tao");
	TheStudent->sex = 'm';
	strcpy(TheStudent->StudentID, "200104088");
	TheStudent->birthday->year = 1983;
	TheStudent->birthday->month = 2;
	TheStudent->birthday->day = 14;
	printf("result:\n");
	printf("name: %s\n", TheStudent->name);
	switch(TheStudent->sex)
	{
	case 'm':
		printf("sex: male\n");
		break;
	case 'f':
		printf("sex: female\n");
		break;
	}
	printf("student ID:%s\n", TheStudent->StudentID);
	printf("birthday:%d,%d,%d", TheStudent->birthday->year, TheStudent->birthday->month, TheStudent->birthday->day);
	free(TheStudent);
}