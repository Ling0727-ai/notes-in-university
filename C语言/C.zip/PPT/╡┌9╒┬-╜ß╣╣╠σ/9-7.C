#include <stdio.h>
#include <stdio.h>
void main()
{
	enum {mon=1, tue,wen=30};
	int i;
	scanf("%d", &i);
	switch(i)
	{
	case mon:
		printf("111");
		break;
	case tue:
		printf("222");
		break;
	}
}
