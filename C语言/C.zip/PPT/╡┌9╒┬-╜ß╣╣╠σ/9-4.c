#include <stdio.h>

struct date
{
	int year;
	int month;
	int day;
};

struct student
{
	char name[11];
	char sex;
	char StudentID[10];
	struct date birthday;
	float score;
};

struct student ReadStudentInformation()
{
	struct student AStudent;
	char *pt, cTemp;
	printf("name:");
	pt = AStudent.name;
	do{
		cTemp = getchar();
		*pt++ = cTemp;
	}while(cTemp != '\n');
	*(pt-1) = '\0';/*different: *(pt--) = '\0';*/
	printf("sex:");
	AStudent.sex = getchar();
	printf("student ID:");
	scanf("%s", &AStudent.StudentID);
	printf("birthday:");
	scanf("%d,%d,%d", &AStudent.birthday.year, &AStudent.birthday.month, &AStudent.birthday.day);
	cTemp = getchar();
	return AStudent;
}

void DisplayStudentInfo(struct student aStudent)
{
	printf("name: %s\n", aStudent.name);
	switch(aStudent.sex)
	{
	case 'm':
		printf("sex: male\n");
		break;
	case 'f':
		printf("sex: female\n");
		break;
	}
	printf("student ID:%s\n", aStudent.StudentID);
	printf("birthday:%d,%d,%d\n", aStudent.birthday.year, aStudent.birthday.month, aStudent.birthday.day);
}

main()
{
	struct student TheStudent[10];
	int i;
	char cTemp, *pt;
	for(i=0; i<3; i++)
	{
		printf("please input the %dth student's infomation\n", i+1);
		TheStudent[i] = ReadStudentInformation();
	}
	printf("result:\n");
	for(i=0; i<3; i++)
	{
		printf("pthe %dth student's infomation\n", i+1);
		DisplayStudentInfo(TheStudent[i]);
	}
}