#include <stdio.h>

struct date
{
	int year;
	int month;
	int day;
};

struct student
{
	char name[11];
	char sex;
	char StudentID[10];
	struct date birthday;
	float score;
};

main()
{
	struct student TheStudent;
	struct date TheDate;
	strcpy(TheStudent.name, "li tao");
	TheStudent.sex = 'm';
	strcpy(TheStudent.StudentID, "200104088");
	TheDate.year = 1983;
	TheDate.month = 2;
	TheDate.day = 14;
	TheStudent.birthday = TheDate;
}